#ifndef __UART_H__
#define __UART_H__

void Init_UART();
void UART_SendString(unsigned char *String);

#endif