#ifndef __MAIN_H
#define __MAIN_H

#include <MSP430F5438A.H>

#endif