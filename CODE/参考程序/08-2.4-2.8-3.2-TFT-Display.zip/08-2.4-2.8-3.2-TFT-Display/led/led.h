#ifndef __LED_H__
#define __LED_H__

#include "../sys/sys.h"

void Init_LED();
void LED_ON();
void LED_OFF();

#endif