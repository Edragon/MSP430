#ifndef __MAIN_H__
#define __MAIN_H__

#include <msp430f5438a.h>

#include "../sys/sys.h"
#include "../hs0038/hs0038.h"
#include "../uart/uart.h"
#include "../time/time.h"

#endif