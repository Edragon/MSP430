#ifndef __MAIN_H__
#define __MAIN_H__

#include <msp430f5438a.h>

#include "../sys/sys.h"
#include "../sd/sd.h"
#include "../uart/uart.h"
#include "../sd/mmc.h"
#include "../sd/FAT16.h"

#endif