#ifndef __MAIN_H__
#define __MAIN_H__

#include <msp430f5438a.h>

#include "../sys/sys.h"
#include "../ds1302/ds1302.h"
#include "../uart/uart.h"

#endif