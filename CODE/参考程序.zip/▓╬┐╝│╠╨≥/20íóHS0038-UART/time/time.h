#ifndef __TIME_H
#define __TIME_H

#include "../sys/sys.h"

void Set_Timer();
void Stop_Timer();

#endif