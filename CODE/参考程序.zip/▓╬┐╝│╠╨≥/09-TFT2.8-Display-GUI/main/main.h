#ifndef __MAIN_H__
#define __MAIN_H__

#include "../sys/sys.h"
#include "../led/led.h"
#include "../lcd/lcd.h"
#include "../gui/gui.h"

#endif